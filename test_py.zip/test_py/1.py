f = open("test.txt", "w+")
for i in range(1, 6):
    f.write("chriswpf"+str(i)+"\n")
f.close()
f = open("test.txt", "r")
print("读5个字符是:"+f.read(5))
f.seek(0)
print("读一行字符串是:"+f.readline())
f.seek(f.tell()*2)
print(("读第三行字符串是："+f.readline()))
f.seek(0)
print("读所有行字符串是：")
list = f.readlines()
for line in list:
    print(line[:-1], end=' ')
f.close()

