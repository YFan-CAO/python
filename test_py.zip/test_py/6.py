import sqlite3
co = sqlite3.connect(r"C:\Users\Lenovo\Desktop\test.db")
cu = co.cursor()
#INSERT
cu.execute(
    "INSERT INTO student(sid,sname,ssex,sage,sclass) VALUES ('2020007','梦梦','男','17','计算机2002')")
#SELECT
cursor = cu.execute("SELECT sid,sname,ssex,sage,sclass from student")
for row in cursor:
    print ("sid= ",row[0])
    print("sname=",row[1])
    print("ssex=",row[2])
    print("sage=",row[3])
    print("sclass=",row[4])

#UPDATE
cu.execute("UPDATE student set sage=20 where sid = 1")

co.commit()  # 提交数据
#打印
cursor = cu.execute("SELECT sid,sname,ssex,sage,sclass from student")
for row in cursor:
    print ("sid= ",row[0])
    print("sname=",row[1])
    print("ssex=",row[2])
    print("sage=",row[3])
    print("sclass=",row[4])
#Delete
cu.execute("DELETE form Course where sid=2;")
co.commit()
#打印
cursor = cu.execute("SELECT sid,sname,ssex,sage,sclass from Course")
for row in cursor:
    print ("sid= ",row[0])
    print("sname=",row[1])
    print("ssex=",row[2])
    print("sage=",row[3])
    print("sclass=",row[4])
cu.close()
co.close()

