import csv
list = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
f = open(r'test.csv', 'w+', newline='')
cw=csv.writer(f, dialect='excel')
len = len(list)
for i in range(0,len):
    cw.writerow(list[i])
f.close()
cr = csv.reader(open(r"test.csv",encoding="utf-8"))
for row in cr:
    print(row)

