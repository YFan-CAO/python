import xlwt
import xlrd

book = xlwt.Workbook(encoding="utf-8")
sheet = book.add_sheet('sheet_test')
sheet.write(0, 0, '学号')
sheet.write(0, 1, '姓名')
sheet.write(0, 2, '年龄')
sheet.write(0, 3, '班级')
sheet.write(1, 0, '2018001')
sheet.write(2, 0, '2018002')
sheet.write(3, 0, '2018003')
sheet.write(4, 0, '2018004')
sheet.write(5, 0, '2018005')
sheet.write(1, 1, '张珊')
sheet.write(2, 1, '李斯')
sheet.write(3, 1, '王斌')
sheet.write(4, 1, '赵柳')
sheet.write(5, 1, '梦之')
sheet.write(1, 2, '女')
sheet.write(2, 2, '男')
sheet.write(3, 2, '男')
sheet.write(4, 2, '女')
sheet.write(5, 2, '男')
sheet.write(1, 3, '18')
sheet.write(2, 3, '19')
sheet.write(3, 3, '19')
sheet.write(4, 3, '18')
sheet.write(5, 3, '17')
sheet.write(1, 4, '计算机2002')
sheet.write(2, 4, '计算机2002')
sheet.write(3, 4, '计算机2002')
sheet.write(4, 4, '计算机2002')
sheet.write(5, 4, '计算机2002')

book.save(r'test.xls')

wb = xlrd.open_workbook(r"test.xls")
print("student信息如下：")
for s in wb.sheets():
    for i in range(s.nrows):
        print(s.row(i)[0].value, end=' ')
        print(s.row(i)[1].value, end=' ')
        print(s.row(i)[2].value, end=' ')
        print(s.row(i)[3].value, end=' ')
        print(s.row(i)[4].value, end=' ')
        print()





