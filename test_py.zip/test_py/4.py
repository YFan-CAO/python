f = open("test.doc", "w+")
for i in range(0, 4):
    f.write("华中农业大学"+str(i+1)+'\n')

f.close()
f = open("test.doc", 'r')
print("读6个文字是："+f.read(6))
f.seek(0)
print("读第一行文字是："+f.readline())
f.seek(f.tell()*2)
print("读取第三行文字是："+f.readline())
f.seek(0)
print("读取所有行文字是：")
list = f.readlines()
for s in list:
    print(s[:7], end=' ')

f.close()

