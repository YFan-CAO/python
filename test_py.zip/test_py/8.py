import pymysql
def get_conn():
    conn = pymysql.connect('localhost', 'root', '200333', 'test_db', charset="utf-8")
    return conn
def insert_many(sql, args):
    conn = get_conn()
    cur = conn.cursor()
    result = cur.executemany(query=sql, args=args)
    print(result)
    conn.commit()
    cur.close()
    conn.close()
def update(sql, args):
    conn = get_conn()
    cur = conn.cursor()
    result = cur.execute(sql, args)
    print(result)
    conn.commit()
    cur.close()
    conn.close()


def delete(sql, args):
    conn = get_conn()
    cur = conn.cursor()
    result = cur.execute(sql, args)
    print(result)
    conn.commit()
    cur.close()
    conn.close()
def query(sql, args):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, args)
    results = cur.fetchall()
    print(type(results))  # 返回<class 'tuple'> tuple元组类型
    for row in results:
        print(row)
        id = row[0]
        name = row[1]
        age = row[2]
        print('id: ' + str(id) + '  name: ' + name + '  age: ' + str(age))
        pass

    conn.commit()
    cur.close()
    conn.close()


if __name__ == '__main__':
    sql = 'insert into test_student_table VALUES (%s,%s,%s)'
    args = [(3, 'li', 11), (4, 'sun', 12), (5, 'zhao', 13)]
    insert_many(sql, args)
    sql = 'UPDATE test_student_table SET NAME=%s WHERE id = %s;'
    args = ('zhangsan', 1)
    update(sql, args)
    sql = 'DELETE FROM test_student_table WHERE id = %s;'
    args = (1,)  # 单个元素的tuple写法
    delete(sql, args)
    sql = 'SELECT  * FROM test_student_table;'
    query(sql, None)
